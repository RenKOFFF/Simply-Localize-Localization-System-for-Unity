using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;

namespace SimplyLocalize.HorrorLab
{
    public interface IHorrorWorldPreparer
    {
        Task<HorrorWorldSession> PrepareAsync(HorrorWorldDefinition definition, string voiceLocale, string visualLocale,
            CancellationToken cancellation, Action<string> progress);
    }

    /// <summary>Finite content set for one loaded world. All lookups are resident-only.</summary>
    public sealed class HorrorWorldSession : IDisposable
    {
        private readonly Dictionary<string, AudioClip> clips = new();
        private readonly Dictionary<string, HorrorVisualVariant> visuals = new();
        private readonly Dictionary<string, HorrorRadioSequence> dialogues = new();
        public string VoiceLocale { get; }
        public string VisualLocale { get; }
        public bool IsDisposed { get; private set; }
        public int ClipCount => clips.Count;
        public int VisualCount => visuals.Count;
        internal HorrorWorldSession(string voice, string visual) { VoiceLocale = voice; VisualLocale = visual; }
        internal void AddClip(string id, AudioClip clip) { clips[id] = clip; }
        internal void AddVisual(string id, HorrorVisualVariant variant) { visuals.Add(id, variant); }
        internal void AddDialogue(HorrorRadioSequence sequence) { dialogues.Add(sequence.sequenceId, sequence); }
        public AudioClip Clip(string id) => !IsDisposed && clips.TryGetValue(id, out var clip) ? clip : throw new InvalidOperationException("Unprepared audio: " + id);
        public HorrorVisualVariant Visual(string id) => !IsDisposed && visuals.TryGetValue(id, out var variant) ? variant : throw new InvalidOperationException("Unprepared visual: " + id);
        public HorrorRadioSequence Dialogue(string id) => !IsDisposed && dialogues.TryGetValue(id, out var sequence) ? sequence : throw new InvalidOperationException("Unprepared dialogue: " + id);
        public void Dispose() { if (IsDisposed) return; IsDisposed = true; clips.Clear(); visuals.Clear(); dialogues.Clear(); }
    }

    public sealed class SimplyLocalizeWorldPreparer : IHorrorWorldPreparer
    {
        private readonly HorrorLoadMetrics metrics;
        public SimplyLocalizeWorldPreparer(HorrorLoadMetrics metrics) { this.metrics = metrics; }
        public async Task<HorrorWorldSession> PrepareAsync(HorrorWorldDefinition definition, string voiceLocale, string visualLocale,
            CancellationToken cancellation, Action<string> progress)
        {
            HorrorPreferences.Validate(definition.voiceConfig, voiceLocale); HorrorPreferences.Validate(definition.visualConfig, visualLocale);
            var timer = Stopwatch.StartNew();
            var session = new HorrorWorldSession(voiceLocale, visualLocale);
            LocalizationManager voice = null, visual = null;
            bool success = false;
            try
            {
                progress?.Invoke("UI/LoadingTables"); await Task.Yield(); cancellation.ThrowIfCancellationRequested();
                voice = new LocalizationManager(definition.voiceConfig);
                voice.SetDataProvider(new ObservedResourcesProvider(definition.voiceConfig.resourcesBasePath, metrics, true));
                voice.SetLanguage(voiceLocale);
                visual = new LocalizationManager(definition.visualConfig);
                visual.SetDataProvider(new ObservedResourcesProvider(definition.visualConfig.resourcesBasePath, metrics, true));
                visual.SetLanguage(visualLocale);
                foreach (string key in definition.visualKeys)
                {
                    cancellation.ThrowIfCancellationRequested();
                    var variant = visual.GetAsset<HorrorVisualVariant>(key);
                    if (variant == null || variant.texture == null || (variant.containsText && variant.contentLanguage == null))
                        throw new InvalidOperationException("Missing visual or source-language metadata: " + key);
                    session.AddVisual(key, variant);
                }
                var prepared = new HashSet<string>();
                foreach (var sequence in definition.dialogues)
                {
                    session.AddDialogue(sequence);
                    foreach (var line in sequence.lines)
                    {
                        if (!prepared.Add(line.audioKey)) continue;
                        cancellation.ThrowIfCancellationRequested();
                        progress?.Invoke("UI/LoadingAudio"); await Task.Yield();
                        var clip = voice.GetAsset<AudioClip>(line.audioKey);
                        if (clip == null) throw new InvalidOperationException("Missing required voice: " + line.audioKey);
                        session.AddClip(line.audioKey, clip);
                        if (clip.loadState == AudioDataLoadState.Unloaded)
                        {
                            metrics.audioPreparations++;
                            if (!clip.LoadAudioData()) throw new InvalidOperationException("Cannot prepare audio: " + line.audioKey);
                        }
                        double deadline = Time.realtimeSinceStartupAsDouble + 30;
                        while (clip.loadState == AudioDataLoadState.Loading)
                        {
                            cancellation.ThrowIfCancellationRequested();
                            if (Time.realtimeSinceStartupAsDouble > deadline) throw new TimeoutException("Audio preparation: " + line.audioKey);
                            await Task.Yield();
                        }
                        if (clip.loadState != AudioDataLoadState.Loaded) throw new InvalidOperationException("Audio is not ready: " + line.audioKey);
                    }
                }
                cancellation.ThrowIfCancellationRequested();
                metrics.lastWorldPrepareMs = timer.Elapsed.TotalMilliseconds; success = true; return session;
            }
            finally
            {
                // Tables may reference extra assets. No tables or managers escape into gameplay.
                voice?.ClearCaches(); visual?.ClearCaches();
                if (!success) session.Dispose();
            }
        }
    }
}
