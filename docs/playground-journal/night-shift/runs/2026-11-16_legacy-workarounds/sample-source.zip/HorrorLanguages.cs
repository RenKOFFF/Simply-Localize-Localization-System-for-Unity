using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using SimplyLocalize.Data;
using TMPro;
using UnityEngine;

namespace SimplyLocalize.HorrorLab
{
    public enum InscriptionMode { Off, Auto, Always }

    /// <summary>Sample preferences only. Heavy selections cannot mutate a live session.</summary>
    public sealed class HorrorPreferences
    {
        private const string Prefix = "SimplyLocalize.HorrorLab.v2.";
        private readonly bool persist;
        public string TextLocale { get; private set; }
        public string VoiceLocale { get; private set; }
        public string VisualLocale { get; private set; }
        public InscriptionMode Inscriptions { get; private set; }
        public bool Subtitles { get; private set; }
        public HorrorPreferences(LocalizationConfig text, HorrorWorldDefinition world, bool persist = true)
        {
            this.persist = persist;
            string Saved(string field, LocalizationConfig config, string legacy)
            {
                var code = persist ? PlayerPrefs.GetString(Prefix + field, PlayerPrefs.GetString("SimplyLocalize.HorrorLab.v1." + legacy, config.DefaultLanguageCode)) : config.DefaultLanguageCode;
                return config.HasLanguage(code) ? code : config.DefaultLanguageCode;
            }
            TextLocale = Saved("text", text, "text"); VoiceLocale = Saved("voice", world.voiceConfig, "voice");
            string originalVisual = world.visualConfig.DefaultLanguageCode;
            if (persist && PlayerPrefs.GetInt("SimplyLocalize.HorrorLab.v1.textures", 0) != 0 && world.visualConfig.HasLanguage(TextLocale)) originalVisual = TextLocale;
            VisualLocale = persist ? PlayerPrefs.GetString(Prefix + "visual", originalVisual) : originalVisual;
            if (!world.visualConfig.HasLanguage(VisualLocale)) VisualLocale = world.visualConfig.DefaultLanguageCode;
            int oldSigns = persist ? PlayerPrefs.GetInt("SimplyLocalize.HorrorLab.v1.signs", 1) : 1;
            Inscriptions = (InscriptionMode)Mathf.Clamp(persist ? PlayerPrefs.GetInt(Prefix + "inscriptions", oldSigns == 0 ? 0 : 1) : 1, 0, 2);
            Subtitles = !persist || PlayerPrefs.GetInt(Prefix + "subtitles", PlayerPrefs.GetInt("SimplyLocalize.HorrorLab.v1.subtitles", 1)) != 0;
        }
        public void SetText(string code) { TextLocale = code; Save(); }
        public void SetVoice(string code, LocalizationConfig config) { Validate(config, code); VoiceLocale = code; Save(); }
        public void SetVisual(string code, LocalizationConfig config) { Validate(config, code); VisualLocale = code; Save(); }
        public void SetInscriptions(InscriptionMode mode) { if (!Enum.IsDefined(typeof(InscriptionMode), mode)) throw new ArgumentOutOfRangeException(nameof(mode)); Inscriptions = mode; Save(); }
        public void SetSubtitles(bool value) { Subtitles = value; Save(); }
        public static void Validate(LocalizationConfig config, string code)
        { if (config == null || !config.HasLanguage(code)) throw new ArgumentException("Unsupported locale: " + code); }
        private void Save()
        {
            if (!persist) return;
            PlayerPrefs.SetString(Prefix + "text", TextLocale); PlayerPrefs.SetString(Prefix + "voice", VoiceLocale); PlayerPrefs.SetString(Prefix + "visual", VisualLocale);
            PlayerPrefs.SetInt(Prefix + "inscriptions", (int)Inscriptions); PlayerPrefs.SetInt(Prefix + "subtitles", Subtitles ? 1 : 0); PlayerPrefs.Save();
        }
    }

    [Serializable]
    public sealed class HorrorLoadMetrics
    {
        public int textReads, assetTableReads, audioPreparations;
        public double lastTextPrepareMs, lastWorldPrepareMs, lastFirstPlayCallMs;
        public int TotalReads => textReads + assetTableReads;
    }

    // Delegates to the existing public provider. It does not introduce a replacement loader.
    internal sealed class ObservedResourcesProvider : ILocalizationDataProvider
    {
        private readonly ResourcesDataProvider inner;
        private readonly HorrorLoadMetrics metrics;
        private readonly bool assetsOnly;
        public ObservedResourcesProvider(string path, HorrorLoadMetrics metrics, bool assetsOnly)
        { inner = new ResourcesDataProvider(path); this.metrics = metrics; this.assetsOnly = assetsOnly; }
        public Dictionary<string, string> LoadTextData(string code)
        {
            if (assetsOnly) return new Dictionary<string, string>();
            metrics.textReads++; return inner.LoadTextData(code);
        }
        public bool HasTextData(string code) => !assetsOnly && inner.HasTextData(code);
        public List<LocalizationAssetTable> LoadAssetTables(string code)
        { metrics.assetTableReads++; return inner.LoadAssetTables(code); }
    }

    public sealed class HorrorTextService : IDisposable
    {
        private readonly LocalizationConfig config;
        private readonly HorrorLoadMetrics metrics;
        private LocalizationManager current;
        private readonly IReadOnlyCollection<string> requiredKeys;
        private int generation;
        private bool disposed;
        public string Locale => current?.CurrentLanguage;
        public LanguageProfile Profile => current?.CurrentProfile;
        public event Action Changed;
        public HorrorTextService(LocalizationConfig config, HorrorLoadMetrics metrics, IReadOnlyCollection<string> requiredKeys)
        { this.config = config; this.metrics = metrics; this.requiredKeys = requiredKeys ?? throw new ArgumentNullException(nameof(requiredKeys)); }
        public string Get(string key) => current == null ? key : current.Get(key);
        public string Format(string key, params object[] args) => current == null ? key : current.Get(key, args);
        public async Task ChangeAsync(string locale, CancellationToken cancellation = default)
        {
            if (disposed) throw new ObjectDisposedException(nameof(HorrorTextService));
            HorrorPreferences.Validate(config, locale);
            int request = ++generation;
            // Gives the UI a frame to show preparation. The provider calls below remain synchronous.
            await Task.Yield(); cancellation.ThrowIfCancellationRequested();
            var timer = Stopwatch.StartNew();
            LocalizationManager candidate = null;
            try
            {
                candidate = new LocalizationManager(config);
                candidate.SetDataProvider(new ObservedResourcesProvider(config.resourcesBasePath, metrics, false));
                candidate.SetLanguage(locale); // Loads only the requested locale and its configured fallbacks.
                foreach (var key in requiredKeys)
                    if (!candidate.HasKey(key)) throw new InvalidOperationException("Missing required text: " + key);
                var font = candidate.CurrentProfile.primaryFont;
                if (font != null && font.atlasPopulationMode == AtlasPopulationMode.Dynamic)
                {
                    var characters = new string(string.Concat(requiredKeys.Concat(candidate.GetAllKeys()).Distinct().Select(k => candidate.Get(k)))
                        .Where(c => !char.IsControl(c) && !font.HasCharacter(c, true)).Distinct().ToArray());
                    if (characters.Length != 0)
                    {
                        // This TMP version returns false even when every glyph was already present.
                        // Prepare missing characters, then inspect coverage rather than that return flag.
                        font.TryAddCharacters(characters, out _);
                        var missing = new string(characters.Where(c => !font.HasCharacter(c, true, true)).ToArray());
                        if (missing.Length != 0) throw new InvalidOperationException("The selected font cannot display required characters: " + missing);
                    }
                }
                cancellation.ThrowIfCancellationRequested();
                if (request != generation || disposed) throw new OperationCanceledException();
                var previous = current; current = candidate; candidate = null;
                metrics.lastTextPrepareMs = timer.Elapsed.TotalMilliseconds;
                try { Changed?.Invoke(); } finally { previous?.ClearCaches(); }
            }
            finally { candidate?.ClearCaches(); }
        }
        public void Dispose() { disposed = true; generation++; Changed = null; current?.ClearCaches(); current = null; }
    }
}
