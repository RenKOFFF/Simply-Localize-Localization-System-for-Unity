using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Profiling;
using UnityEngine.SceneManagement;
using Debug = UnityEngine.Debug;

namespace SimplyLocalize.HorrorLab
{
    /// <summary>Opt-in standalone verification. No input events, focus changes or cursor capture.</summary>
    public sealed class HorrorBenchmark : MonoBehaviour
    {
        [Serializable] public sealed class Sample
        {
            public string name;
            public double worldPrepareMs, textPrepareMs, firstPlayCallMs, frameP95Ms, frameMaxMs;
            public long allocatedBytes, managedBytes;
            public int audioObjects, textureObjects, providerReads;
        }
        [Serializable] public sealed class Report
        {
            public string unityVersion, device, graphics, note;
            public bool passed;
            public string failure;
            public long peakAllocatedBytes, peakManagedBytes;
            public double initialTextPrepareMs;
            public string[] startupAudioBeforeMenuCleanup, audioAfterConfigDiscovery;
            public int menuAudioObjects, audioBeforeConfigDiscovery;
            public double peakObservedFrameMs;
            public List<string> checks = new();
            public List<Sample> samples = new();
        }
        private readonly Report report = new();
        private bool finished;
        private void Update()
        {
            if (finished) return;
            report.peakAllocatedBytes = Math.Max(report.peakAllocatedBytes, Profiler.GetTotalAllocatedMemoryLong());
            report.peakManagedBytes = Math.Max(report.peakManagedBytes, GC.GetTotalMemory(false));
            report.peakObservedFrameMs = Math.Max(report.peakObservedFrameMs, Time.unscaledDeltaTime * 1000);
            if (Time.realtimeSinceStartup > 180) { report.failure = "Verification timed out after 180 seconds."; Finish(); }
        }
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        private static void Launch()
        {
            if (!Environment.GetCommandLineArgs().Contains("--nightshift-benchmark")) return;
            var obj = new GameObject("Night Shift Automated Verification"); DontDestroyOnLoad(obj); obj.AddComponent<HorrorBenchmark>();
        }
        private void Check(bool condition, string message)
        { if (!condition) throw new InvalidOperationException(message); report.checks.Add(message); }
        private async void Start()
        {
            Application.targetFrameRate = 60;
            report.unityVersion = Application.unityVersion; report.device = SystemInfo.processorType; report.graphics = SystemInfo.graphicsDeviceType.ToString();
            report.note = "Small fixture, Release Player without Development PlayerConnection. Allocated bytes are the Unity allocator, not process RAM; managed bytes use GC.GetTotalMemory. Peaks sampled once per frame. Null graphics excludes GPU. No gigabyte-scale or physical audio-output-latency claim.";
            Application.logMessageReceived += OnLog;
            try
            {
                var app = HorrorApp.Instance;
                if (app == null) throw new InvalidOperationException("Benchmark must start from NightShiftMenu.");
                report.startupAudioBeforeMenuCleanup = DescribeAudio();
                await app.Initialization;
                report.initialTextPrepareMs = app.Metrics.lastTextPrepareMs;
                report.menuAudioObjects = Resources.FindObjectsOfTypeAll<AudioClip>().Length;
                Check(report.menuAudioObjects == 0, "Menu releases incidental audio objects from root config discovery");
                Check(app.State == HorrorAppState.Menu && app.Session == null && app.Game == null, "Bootstrap contains no loaded world");
                Check(Cursor.lockState == CursorLockMode.None, "Startup does not capture cursor");
                var originalManager = Localization.Manager;
                await Matrix(app);
                var required = new[] { "UI/Title" };
                using (var staged = new HorrorTextService(app.textConfig, new HorrorLoadMetrics(), required))
                {
                    await staged.ChangeAsync(app.Text.Locale);
                    string previous = staged.Locale; required[0] = "Missing/DeliberateValidationFixture";
                    bool rejectedText = false;
                    try { await staged.ChangeAsync(app.textConfig.languages[0].Code); } catch (InvalidOperationException) { rejectedText = true; }
                    Check(rejectedText && staged.Locale == previous && staged.Get("UI/Title") != "UI/Title", "Missing required text never replaces the last successful state");
                }
                var real = new SimplyLocalizeWorldPreparer(app.Metrics);
                var delayed = new Delayed(real, 12); app.SetPreparer(delayed);
                var pending = app.StartWorldAsync(); await Task.Yield();
                Check(app.State == HorrorAppState.PreparingWorld && app.Game == null, "Delayed preparer keeps gameplay unavailable");
                app.CancelPreparation(); await pending;
                Check(app.State == HorrorAppState.Menu && app.Session == null, "Early cancellation leaves clean menu");
                app.SetPreparer(new CancelAfterPrepared(real, app.CancelPreparation)); await app.StartWorldAsync();
                Check(app.State == HorrorAppState.Menu && app.Session == null && !SceneManager.GetSceneByPath(app.worldDefinition.scenePath).isLoaded, "Cancellation after resource preparation rolls back ownership");
                app.SetPreparer(new Failing()); await app.StartWorldAsync();
                Check(app.State == HorrorAppState.Menu && app.Session == null && app.ErrorKey != null, "Failed preparation reports error without publishing world");
                app.SetPreparer(real);
                var sceneLoad = app.StartWorldAsync();
                while (app.State == HorrorAppState.PreparingWorld && app.ProgressKey != "UI/LoadingWorld") await Task.Yield();
                app.CancelPreparation(); await sceneLoad;
                Check(app.State == HorrorAppState.Menu && app.Session == null && !SceneManager.GetSceneByPath(app.worldDefinition.scenePath).isLoaded, "Cancellation during scene loading unloads the unpublished world");
                for (int cycle = 0; cycle < 3; cycle++)
                {
                    app.SetPreparer(cycle == 0 ? delayed : real);
                    app.SetVoice(app.worldDefinition.voiceConfig.languages[cycle % app.worldDefinition.voiceConfig.languages.Count].Code);
                    app.SetVisual(app.worldDefinition.visualConfig.languages[cycle % app.worldDefinition.visualConfig.languages.Count].Code);
                    await app.StartWorldAsync();
                    Check(app.State == HorrorAppState.World && app.Game.Ready, "Cycle " + cycle + ": prepared world published");
                    Check(!app.Hud.VoiceLanguage.interactable && !app.Hud.VisualLanguage.interactable, "Heavy dropdowns locked inside world");
                    bool rejected = false;
                    try { app.SetVisual(app.Preferences.VisualLocale); } catch (InvalidOperationException) { rejected = true; }
                    Check(rejected, "Service rejects heavy changes inside world");
                    app.Presentation.voiceSource.mute = true;
                    int beforeReads = app.Metrics.TotalReads, beforeAudio = app.Metrics.audioPreparations, beforeVisuals = app.Presentation.VisualApplyCount;
                    var clip = app.Session.Clip(app.worldDefinition.dialogues[0].lines[0].audioKey);
                    Check(clip.loadState == AudioDataLoadState.Loaded, "Voice data ready before first Play");
                    var playback = app.Presentation.Dialogue.PlayAsync(app.worldDefinition.dialogues[0].sequenceId);
                    await Task.Yield();
                    Check(app.Presentation.Dialogue.CurrentClip == clip, "Dialogue uses prepared clip by ID");
                    Check(app.Metrics.TotalReads == beforeReads && app.Metrics.audioPreparations == beforeAudio, "First playback performs no provider or audio-data loads");
                    var nextText = app.textConfig.languages[(cycle + 1) % app.textConfig.languages.Count].Code;
                    string voice = app.Session.VoiceLocale, visual = app.Session.VisualLocale;
                    await app.ChangeTextAsync(nextText);
                    Check(app.Text.Locale == nextText && app.Session.VoiceLocale == voice && app.Session.VisualLocale == visual, "Text change preserves independent heavy selections");
                    Check(app.Presentation.Dialogue.CurrentClip == clip && app.Presentation.VisualApplyCount == beforeVisuals, "Text change neither interrupts current voice nor reapplies visuals");
                    var line = app.Presentation.Dialogue.CurrentLine;
                    Check(app.Hud.Subtitle.text == app.Text.Format("UI/SubtitleLine", app.Text.Get(line.speakerKey), app.Text.Get(line.textKey)), "Visible subtitle follows text service");
                    app.Presentation.Dialogue.Stop(); try { await playback; } catch (OperationCanceledException) { }
                    string retainedText = app.Text.Locale;
                    await app.ChangeTextAsync("unsupported-test-locale");
                    Check(app.Text.Locale == retainedText, "Invalid text request retains previous text state");
                    using (var cancelled = new CancellationTokenSource())
                    {
                        cancelled.Cancel(); try { await app.Text.ChangeAsync(app.textConfig.languages[0].Code, cancelled.Token); } catch (OperationCanceledException) { }
                    }
                    Check(app.Text.Locale == retainedText, "Cancelled text request retains previous state");
                    foreach (var sign in app.Game.interactables.Where(i => i.kind == HorrorInteraction.Sign))
                    {
                        var variant = app.Session.Visual(sign.textureKey);
                        Check(!app.Presentation.ShouldTranslate(sign, app.Text.Locale, InscriptionMode.Off), "Off suppresses inscription " + sign.name);
                        Check(app.Presentation.ShouldTranslate(sign, app.Text.Locale, InscriptionMode.Auto) == (variant.contentLanguage.Code != app.Text.Locale), "Auto uses actual visual source " + sign.name);
                        Check(app.Presentation.ShouldTranslate(sign, app.Text.Locale, InscriptionMode.Always), "Always exposes inscription " + sign.name);
                        variant.containsText = false;
                        try { Check(!app.Presentation.ShouldTranslate(sign, app.Text.Locale, InscriptionMode.Always), "Neutral images never offer an inscription translation"); }
                        finally { variant.containsText = true; }
                    }
                    beforeReads = app.Metrics.TotalReads; beforeAudio = app.Metrics.audioPreparations;
                    var game = app.Game;
                    var door = game.interactables.First(i => i.kind == HorrorInteraction.Door);
                    game.Interact(door); Check(!game.DoorOpen, "Door initially locked");
                    game.Interact(game.interactables.First(i => i.kind == HorrorInteraction.Key));
                    game.Interact(door); Check(game.HasKey && game.DoorOpen, "Key and door work without localization knowledge");
                    game.Interact(game.interactables.First(i => i.kind == HorrorInteraction.Note)); game.CloseDocument();
                    var frames = new List<double>();
                    for (int frame = 0; frame < 120; frame++) { await Task.Yield(); frames.Add(Time.unscaledDeltaTime * 1000); }
                    Check(app.Metrics.TotalReads == beforeReads && app.Metrics.audioPreparations == beforeAudio, "Steady gameplay and documents perform no loads");
                    Check(Cursor.lockState == CursorLockMode.None, "Automation never takes desktop cursor");
                    Capture("world-" + cycle, app, frames);
                    // The verifier must not itself keep the last clip alive across UnloadUnusedAssets.
                    clip = null; playback = null;
                    var owned = app.Session;
                    await app.LeaveWorldAsync();
                    Check(app.Session == null && app.Game == null && owned.IsDisposed && owned.ClipCount == 0 && owned.VisualCount == 0, "Session releases all owned references on exit");
                    Capture("menu-after-" + cycle, app, null);
                    Check(report.samples.Last().audioObjects == 0, "No AudioClip remains after exit from this fixture");
                }
                var menus = report.samples.Where(s => s.name.StartsWith("menu-after")).ToArray();
                Check(menus.Last().audioObjects <= menus.First().audioObjects, "Repeated world exits do not accumulate loaded AudioClip objects");
                Check(menus.Last().textureObjects <= menus.First().textureObjects + 3, "Repeated exits have bounded texture count (font atlas allowance)");
                Check(ReferenceEquals(originalManager, Localization.Manager), "Global Simply Localize facade remains untouched");
                // Diagnose the same root Resources query used by the plugin auto-initializer.
                // This probe is verification-only, after the world lifetime checks have finished.
                report.audioBeforeConfigDiscovery = Resources.FindObjectsOfTypeAll<AudioClip>().Length;
                var discovered = Resources.LoadAll<LocalizationConfig>("");
                report.audioAfterConfigDiscovery = DescribeAudio();
                discovered = null;
                var cleanup = Resources.UnloadUnusedAssets(); while (!cleanup.isDone) await Task.Yield();
                Check(Resources.FindObjectsOfTypeAll<AudioClip>().Length == 0, "Config discovery probe releases incidental audio objects on transition");
                report.passed = true;
            }
            catch (Exception error) { report.failure = error.ToString(); Debug.LogError(report.failure); }
            finally { Finish(); }
        }
        private async Task Matrix(HorrorApp app)
        {
            int combinations = 0;
            var preparer = new SimplyLocalizeWorldPreparer(app.Metrics);
            foreach (var voice in app.worldDefinition.voiceConfig.languages)
            foreach (var visual in app.worldDefinition.visualConfig.languages)
            {
                using (var session = await preparer.PrepareAsync(app.worldDefinition, voice.Code, visual.Code, CancellationToken.None, null))
                {
                    foreach (var text in app.textConfig.languages)
                    {
                        await app.ChangeTextAsync(text.Code);
                        if (app.Text.Locale != text.Code || app.ErrorKey != null) throw new InvalidOperationException("Text preparation failed for " + text.Code);
                        foreach (var id in app.worldDefinition.visualKeys)
                        {
                            var variant = session.Visual(id);
                            if (variant == null || variant.texture == null || variant.contentLanguage == null) throw new InvalidOperationException("Incomplete variant: " + id);
                        }
                        if (session.VoiceLocale != voice.Code || session.VisualLocale != visual.Code) throw new InvalidOperationException("Channel coupling");
                        combinations++;
                    }
                }
            }
            Check(combinations == app.textConfig.languages.Count * app.worldDefinition.voiceConfig.languages.Count * app.worldDefinition.visualConfig.languages.Count, "All independent text/voice/visual combinations prepared: " + combinations);
            var unload = Resources.UnloadUnusedAssets(); while (!unload.isDone) await Task.Yield();
        }
        private void Capture(string name, HorrorApp app, List<double> frames)
        {
            frames?.Sort();
            report.samples.Add(new Sample { name = name, worldPrepareMs = app.Metrics.lastWorldPrepareMs, textPrepareMs = app.Metrics.lastTextPrepareMs,
                firstPlayCallMs = app.Metrics.lastFirstPlayCallMs, allocatedBytes = Profiler.GetTotalAllocatedMemoryLong(), managedBytes = GC.GetTotalMemory(false),
                audioObjects = Resources.FindObjectsOfTypeAll<AudioClip>().Length, textureObjects = Resources.FindObjectsOfTypeAll<Texture>().Length,
                providerReads = app.Metrics.TotalReads, frameP95Ms = frames == null ? 0 : frames[(int)(frames.Count * .95)], frameMaxMs = frames == null ? 0 : frames.Last() });
        }
        private static string[] DescribeAudio() => Resources.FindObjectsOfTypeAll<AudioClip>().Select(c => c.name + ": " + c.loadState).OrderBy(s => s).ToArray();
        private void OnLog(string message, string stack, LogType type)
        { if ((type == LogType.Exception || type == LogType.Error) && report.failure == null) report.failure = message + "\n" + stack; }
        private void Finish()
        {
            if (finished) return; finished = true; Application.logMessageReceived -= OnLog;
            if (report.failure != null) report.passed = false;
            var args = Environment.GetCommandLineArgs(); int index = Array.IndexOf(args, "--nightshift-report");
            string path = index >= 0 && index + 1 < args.Length ? args[index + 1] : Path.Combine(Application.persistentDataPath, "nightshift-benchmark.json");
            Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(path))); File.WriteAllText(path, JsonUtility.ToJson(report, true));
            Debug.Log("Night Shift verification: " + report.passed + " report=" + path); Application.Quit(report.passed ? 0 : 1);
        }
        private sealed class Delayed : IHorrorWorldPreparer
        {
            private readonly IHorrorWorldPreparer inner; private readonly int frames;
            public Delayed(IHorrorWorldPreparer inner, int frames) { this.inner = inner; this.frames = frames; }
            public async Task<HorrorWorldSession> PrepareAsync(HorrorWorldDefinition definition, string voice, string visual, CancellationToken token, Action<string> progress)
            { for (int i = 0; i < frames; i++) { token.ThrowIfCancellationRequested(); await Task.Yield(); } return await inner.PrepareAsync(definition, voice, visual, token, progress); }
        }
        private sealed class CancelAfterPrepared : IHorrorWorldPreparer
        {
            private readonly IHorrorWorldPreparer inner; private readonly Action cancel;
            public CancelAfterPrepared(IHorrorWorldPreparer inner, Action cancel) { this.inner = inner; this.cancel = cancel; }
            public async Task<HorrorWorldSession> PrepareAsync(HorrorWorldDefinition definition, string voice, string visual, CancellationToken token, Action<string> progress)
            { var result = await inner.PrepareAsync(definition, voice, visual, token, progress); cancel(); return result; }
        }
        private sealed class Failing : IHorrorWorldPreparer
        {
            public Task<HorrorWorldSession> PrepareAsync(HorrorWorldDefinition definition, string voice, string visual, CancellationToken token, Action<string> progress)
                => Task.FromException<HorrorWorldSession>(new IOException("Expected injected preparation failure"));
        }
    }
}
