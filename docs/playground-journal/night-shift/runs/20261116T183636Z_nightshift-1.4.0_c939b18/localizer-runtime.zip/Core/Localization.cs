using System;
using System.Collections.Generic;
using SimplyLocalize.Data;
using UnityEngine;

namespace SimplyLocalize
{
    /// <summary>
    /// Public static API for the localization system.
    /// This is the main entry point for getting translations, switching languages,
    /// and subscribing to language change events.
    ///
    /// Initialize once at startup with a LocalizationConfig asset, then use anywhere.
    ///
    /// Usage:
    ///   Localization.Initialize(config);
    ///   Localization.SetLanguage("ru");
    ///   string text = Localization.Get("UI/MainMenu/Play");
    ///   string plural = Localization.Get("Game/Loot/Coins", 5);
    /// </summary>
    public static class Localization
    {
        private static LocalizationManager _manager;

        // ──────────────────────────────────────────────
        //  Initialization
        // ──────────────────────────────────────────────

        /// <summary>
        /// Initializes the localization system with the given config.
        /// Automatically sets the default language.
        /// </summary>
        public static void Initialize(LocalizationConfig config)
        {
            InitializeCore(config, config != null ? config.DefaultLanguageCode : null, false);
        }

        /// <summary>
        /// Initializes with config and immediately sets a specific language by code.
        /// If the language code is not found, falls back to default or throws error
        /// based on throwOnMissing parameter.
        /// </summary>
        /// <param name="config">The localization config asset.</param>
        /// <param name="languageCode">Language code to set (e.g. "ru", "en").</param>
        /// <param name="throwOnMissing">If true, throws exception when language not found.
        /// If false, falls back to default language.</param>
        public static void Initialize(LocalizationConfig config, string languageCode,
            bool throwOnMissing = false)
        {
            InitializeCore(config, languageCode, throwOnMissing);
        }

        internal static LocalizationManager InitializeForBootstrap(LocalizationConfig config, LanguageProfile profile) =>
            InitializeCore(config, profile != null ? profile.Code : null, profile != null);

        private static LocalizationManager InitializeCore(LocalizationConfig config, string languageCode, bool throwOnMissing)
        {
            if (config == null)
            {
                Debug.LogError("[SimplyLocalize] Cannot initialize: config is null");
                return null;
            }

            var profile = config.GetProfile(languageCode);
            if (profile == null && throwOnMissing)
            {
                throw new ArgumentException(
                    $"[SimplyLocalize] Language '{languageCode}' not found in config '{config.name}'. " +
                    $"Available: {string.Join(", ", config.GetLanguageCodes())}");
            }
            if (profile == null)
            {
                if (!string.IsNullOrEmpty(languageCode))
                    LocalizationLogger.LogWarning($"Language '{languageCode}' not found in config '{config.name}', using default");
                profile = config.defaultLanguage;
            }

            // Prepare completely before replacing a working instance. Events see only committed state.
            var candidate = new LocalizationManager(config);
            if (profile != null) candidate.SetLanguage(profile);
            Shutdown();
            _manager = candidate;
            // Public static logging follows the committed facade, not arbitrary standalone managers.
            LocalizationLogger.Enabled = config.enableLogging;
            LocalizationLogger.EnabledInBuild = config.enableLoggingInBuild;
            _manager.OnLanguageChanged += ForwardLanguageChanged;
            _manager.OnProfileChanged += ForwardProfileChanged;
            if (candidate.CurrentProfile != null)
            {
                ForwardLanguageChanged(candidate.CurrentLanguage);
                if (ReferenceEquals(_manager, candidate)) ForwardProfileChanged(candidate.CurrentProfile);
            }
            LocalizationLogger.Log(config, $"Localization initialized with '{candidate.CurrentLanguage}'");
            // Subscribers can replace the manager while handling startup events. The caller
            // owns this candidate, never a replacement created by another initializer.
            return candidate;
        }

        /// <summary>
        /// Initializes by finding config in Resources automatically.
        /// Sets the default language from config.
        /// Convenience method — no need to pass config reference.
        /// </summary>
        public static void Initialize()
        {
            if (IsInitialized) return;

            var config = FindResourceConfig(false);
            if (config != null) Initialize(config);
        }

        /// <summary>
        /// Shuts down the localization system and releases all cached data.
        /// </summary>
        public static void Shutdown()
        {
            if (_manager == null)
                return;

            _manager.OnLanguageChanged -= ForwardLanguageChanged;
            _manager.OnProfileChanged -= ForwardProfileChanged;
            _manager.ClearCaches();
            _manager = null;
        }

        private static void ForwardLanguageChanged(string language) => OnLanguageChanged?.Invoke(language);
        private static void ForwardProfileChanged(LanguageProfile profile) => OnProfileChanged?.Invoke(profile);

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetRuntimeState()
        {
            Shutdown();
            OnLanguageChanged = null;
            OnProfileChanged = null;
            LocalizationLogger.Enabled = LocalizationLogger.EnabledInBuild = false;
            Pluralization.PluralRuleProvider.ResetRuntimeState();
        }

        internal static LocalizationConfig FindResourceConfig(bool automaticOnly)
        {
            var config = Resources.Load<LocalizationConfig>(LocalizationConfig.StartupResourcePath);
            if (config == null && !automaticOnly)
                Debug.LogError("[SimplyLocalize] No startup config at Resources/SimplyLocalizeSettings.asset. Run project setup or pass a config to Localization.Initialize(config).");
            return config != null && (!automaticOnly || config.autoInitialize) ? config : null;
        }

        /// <summary>
        /// Whether the system has been initialized.
        /// </summary>
        public static bool IsInitialized => _manager != null;

        /// <summary>
        /// The underlying LocalizationManager instance, or null if not initialized.
        /// Exposed for advanced scenarios; most code should use the static methods on this class.
        ///
        /// If you use a DI container, prefer registering and injecting LocalizationManager directly
        /// instead of relying on this static facade.
        /// </summary>
        public static LocalizationManager Manager => _manager;

        // ──────────────────────────────────────────────
        //  Language
        // ──────────────────────────────────────────────

        /// <summary>
        /// The currently active language code (e.g. "en", "ru").
        /// </summary>
        public static string CurrentLanguage => _manager?.CurrentLanguage;

        /// <summary>
        /// The display profile for the current language.
        /// Contains font, size, spacing, and direction settings.
        /// </summary>
        public static LanguageProfile CurrentProfile => _manager?.CurrentProfile;

        /// <summary>
        /// The active configuration asset.
        /// </summary>
        public static LocalizationConfig Config => _manager?.Config;

        /// <summary>
        /// Switches to the specified language by code.
        /// Loads translation data if not already cached, then fires OnLanguageChanged.
        /// </summary>
        public static void SetLanguage(string languageCode)
        {
            EnsureInitialized();
            _manager.SetLanguage(languageCode);
        }

        /// <summary>
        /// Switches to the specified language by profile reference.
        /// Preferred over the string overload — no typos, full IntelliSense.
        /// </summary>
        public static void SetLanguage(LanguageProfile profile)
        {
            EnsureInitialized();
            _manager.SetLanguage(profile);
        }

        /// <summary>
        /// Attempts to set the language matching the device's system language.
        /// Falls back to the config's default language if no match is found.
        /// Returns the profile that was set, or null if nothing matched.
        /// </summary>
        public static LanguageProfile SetLanguageAuto()
        {
            EnsureInitialized();

            var systemLang = Application.systemLanguage;
            var profile = _manager.Config.GetProfileBySystemLanguage(systemLang);

            if (profile != null)
            {
                _manager.SetLanguage(profile);
                return profile;
            }

            // Fall back to default
            if (_manager.Config.defaultLanguage != null)
            {
                _manager.SetLanguage(_manager.Config.defaultLanguage);
                return _manager.Config.defaultLanguage;
            }

            LocalizationLogger.LogWarning(
                $"No language profile matches SystemLanguage.{systemLang}, and no default is set");
            return null;
        }

        /// <summary>
        /// Returns all language profiles defined in the config.
        /// </summary>
        public static IReadOnlyList<LanguageProfile> AvailableLanguages =>
            _manager?.Config?.languages;

        // ──────────────────────────────────────────────
        //  Text
        // ──────────────────────────────────────────────

        /// <summary>
        /// Gets the translated string for the given key.
        /// Fallback chain: current language → fallback language → key.
        /// </summary>
        public static string Get(string key)
        {
            if (_manager == null) return key ?? string.Empty;
            return _manager.Get(key);
        }

        /// <summary>
        /// Gets the translated string with indexed parameter substitution and pluralization.
        ///
        /// Example:
        ///   JSON: "You found {0} {0|coin|coins}"
        ///   Code: Localization.Get("loot_coins", 5) → "You found 5 coins"
        /// </summary>
        public static string Get(string key, params object[] args)
        {
            if (_manager == null) return key ?? string.Empty;
            return _manager.Get(key, args);
        }

        /// <summary>
        /// Gets the translated string with named parameter substitution and pluralization.
        ///
        /// Example:
        ///   JSON: "{playerName} found {count} {count|coin|coins}"
        ///   Code: Localization.Get("loot", new Dictionary&lt;string, object&gt; {
        ///       { "playerName", "Alex" }, { "count", 5 }
        ///   });
        ///   Result: "Alex found 5 coins"
        /// </summary>
        public static string Get(string key, Dictionary<string, object> namedArgs)
        {
            if (_manager == null) return key ?? string.Empty;
            return _manager.Get(key, namedArgs);
        }

        /// <summary>
        /// Gets the translated string with both indexed and named parameters.
        ///
        /// Example:
        ///   JSON: "{playerName} has {0} {0|life|lives} left"
        ///   Code: Localization.Get("lives", new object[] { 3 },
        ///       new Dictionary&lt;string, object&gt; { { "playerName", "Alex" } });
        ///   Result: "Alex has 3 lives left"
        /// </summary>
        public static string Get(string key, object[] args, Dictionary<string, object> namedArgs)
        {
            if (_manager == null) return key ?? string.Empty;
            return _manager.Get(key, args, namedArgs);
        }

        // ──────────────────────────────────────────────
        //  Assets
        // ──────────────────────────────────────────────

        /// <summary>
        /// Gets a localized asset of any type from asset tables.
        /// Follows the fallback chain: current → per-language → global.
        ///
        /// Usage:
        ///   var sprite = Localization.GetAsset&lt;Sprite&gt;("ui/flag");
        ///   var clip = Localization.GetAsset&lt;AudioClip&gt;("voice/intro");
        ///   var material = Localization.GetAsset&lt;Material&gt;("fx/hit");
        /// </summary>
        public static T GetAsset<T>(string key) where T : UnityEngine.Object
        {
            return _manager?.GetAsset<T>(key);
        }

        // ──────────────────────────────────────────────
        //  Queries
        // ──────────────────────────────────────────────

        /// <summary>
        /// Checks whether an entry exists for the key in the current or fallback language,
        /// including null/empty values. Get skips empty translations when resolving fallback.
        /// </summary>
        public static bool HasKey(string key)
        {
            return _manager != null && _manager.HasKey(key);
        }

        /// <summary>
        /// Checks whether a specific language has an entry for the key, including null/empty values.
        /// Loads the language data if not already cached.
        /// </summary>
        public static bool HasTranslation(string key, string languageCode)
        {
            return _manager != null && _manager.HasTranslation(key, languageCode);
        }

        /// <summary>
        /// Returns all translation keys loaded for the current language.
        /// </summary>
        public static IEnumerable<string> GetAllKeys()
        {
            return _manager?.GetAllKeys() ?? Array.Empty<string>();
        }

        // ──────────────────────────────────────────────
        //  Data Provider
        // ──────────────────────────────────────────────

        /// <summary>
        /// Replaces the data provider at runtime (e.g. to switch to Addressables).
        /// Reloads the active language and fallbacks, then notifies consumers.
        /// A loading failure preserves the previous provider and cached state.
        /// Providers and their assets remain caller-owned.
        /// </summary>
        public static void SetDataProvider(ILocalizationDataProvider provider)
        {
            EnsureInitialized();
            _manager.SetDataProvider(provider);
        }

        /// <summary>
        /// Reloads current and fallback data and notifies consumers even if the language is unchanged.
        /// A loading failure preserves the last successful state and propagates the exception.
        /// </summary>
        public static void Reload()
        {
            _manager?.Reload();
        }

        // ──────────────────────────────────────────────
        //  Events
        // ──────────────────────────────────────────────

        /// <summary>
        /// Fired when the active language changes or its data is successfully reloaded/replaced.
        /// Passes the active language code after loading has completed.
        /// All localized components subscribe to this automatically.
        /// </summary>
        public static event Action<string> OnLanguageChanged;

        /// <summary>
        /// Fired after OnLanguageChanged, including successful reloads and provider changes.
        /// Passes the active language profile (font, sizing, direction, etc.).
        /// Components use this to apply visual settings.
        /// </summary>
        public static event Action<LanguageProfile> OnProfileChanged;

        // ──────────────────────────────────────────────
        //  Internal
        // ──────────────────────────────────────────────

        private static void EnsureInitialized()
        {
            if (_manager == null)
                throw new InvalidOperationException(
                    "[SimplyLocalize] Not initialized. Call Localization.Initialize(config) first.");
        }
    }
}
