using System;
using System.Collections.Generic;
using UnityEngine;

namespace SimplyLocalize.Data
{
    /// <summary>
    /// Loads localization data from the Resources folder.
    ///
    /// Expected folder structure inside Resources:
    ///
    ///   {basePath}/
    ///   ├── en/
    ///   │   ├── text/              — all .json files are loaded and merged
    ///   │   │   ├── en.json
    ///   │   │   ├── items.json
    ///   │   │   └── menu.json
    ///   │   └── AssetTable.asset   — per-language asset table (sprites, audio, custom types)
    ///   ├── ru/
    ///   │   ├── text/
    ///   │   └── AssetTable.asset
    ///   ...
    ///
    /// Text:   All .json files inside {basePath}/{lang}/text/ are loaded and merged.
    ///         Duplicate keys across files: last loaded wins (no guaranteed order).
    ///
    /// Assets: Place one or more LocalizationAssetTable SOs in {basePath}/{lang}/.
    ///         At runtime, call Localization.GetAsset&lt;T&gt;(key) — the manager searches
    ///         all tables for the current language, then the fallback chain.
    /// </summary>
    public class ResourcesDataProvider : ILocalizationDataProvider
    {
        private readonly string _basePath;

        public ResourcesDataProvider(string basePath)
        {
            if (!LocalizationConfig.IsResourcePathValid(basePath))
                throw new ArgumentException($"Invalid Resources base path '{basePath}': use a relative path with '/'.", nameof(basePath));
            _basePath = basePath.TrimEnd('/');
        }

        private string LanguagePath(string languageCode)
        {
            if (!LocalizationConfig.IsLanguageCodeValid(languageCode))
                throw new ArgumentException($"Invalid language code '{languageCode}' for Resources/{_basePath}.", nameof(languageCode));
            return string.IsNullOrEmpty(_basePath) ? languageCode : $"{_basePath}/{languageCode}";
        }

        public Dictionary<string, string> LoadTextData(string languageCode)
        {
            string textFolder = $"{LanguagePath(languageCode)}/text";
            var allTextAssets = Resources.LoadAll<TextAsset>(textFolder);

            if (allTextAssets == null || allTextAssets.Length == 0)
            {
                LocalizationLogger.LogWarning(
                    $"No text files found at Resources/{textFolder}/ for language '{languageCode}'");
                return new Dictionary<string, string>();
            }

            var merged = new Dictionary<string, string>();
            var sources = new Dictionary<string, string>();

            try
            {
                for (int i = 0; i < allTextAssets.Length; i++)
                {
                    var asset = allTextAssets[i];
                    Dictionary<string, string> parsed;
                    try { parsed = LocalizationFileParser.Parse(asset.text); }
                    catch (Exception error) when (error is FormatException || error is OverflowException || error is ArgumentOutOfRangeException)
                    {
                        throw new FormatException($"Invalid localization JSON at Resources/{textFolder}/{asset.name} (language '{languageCode}'): {error.Message}", error);
                    }

                    foreach (var kvp in parsed)
                    {
                        if (sources.TryGetValue(kvp.Key, out var previous))
                            LocalizationLogger.LogWarning($"Duplicate key '{kvp.Key}' for '{languageCode}' in Resources/{textFolder}: '{previous}' and '{asset.name}'. Last loaded value wins; remove the duplicate to avoid load-order dependence.");
                        merged[kvp.Key] = kvp.Value;
                        sources[kvp.Key] = asset.name;
                    }

                    LocalizationLogger.Log(
                        $"Loaded {parsed.Count} keys from '{asset.name}.json' ({languageCode})");
                }
            }
            finally
            {
                // Release loaded text assets even if parsing one of the files fails.
                for (int i = 0; i < allTextAssets.Length; i++)
                    Resources.UnloadAsset(allTextAssets[i]);
            }

            LocalizationLogger.Log(
                $"Total: {merged.Count} keys from {allTextAssets.Length} file(s) for '{languageCode}'");

            return merged;
        }

        public bool HasTextData(string languageCode)
        {
            string textFolder = $"{LanguagePath(languageCode)}/text";
            var assets = Resources.LoadAll<TextAsset>(textFolder);
            bool exists = assets != null && assets.Length > 0;

            if (assets != null)
            {
                for (int i = 0; i < assets.Length; i++)
                    Resources.UnloadAsset(assets[i]);
            }

            return exists;
        }

        public List<LocalizationAssetTable> LoadAssetTables(string languageCode)
        {
            string path = LanguagePath(languageCode);
            var tables = Resources.LoadAll<LocalizationAssetTable>(path);

            var result = new List<LocalizationAssetTable>();

            if (tables != null)
            {
                result.AddRange(tables);
                LocalizationLogger.Log(
                    $"Loaded {tables.Length} asset table(s) for '{languageCode}'");
            }

            return result;
        }
    }
}
